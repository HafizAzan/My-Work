export const END_POINTS_URL = {
  TODOS: "/hello",
};
